import React, { Component } from 'react';
import {
  Text,
  View,
  StyleSheet,
  Button,
  Alert,
  Image,
  TouchableOpacity,
} from 'react-native';

// Unirest,
import { Constants, Google, Location, Permissions } from 'expo';

// or any pure javascript modules available in npm
import { Card } from 'react-native-elements'; // Version can be specified in package.json

export default class App extends Component {
  state = {
    locationResult: null,
  };

  componentDidMount() {
    this._getLocationAsync();
  }

  _handleButtonPress = () => {
    Alert.alert('We will be sure to keep you safe!');
  };

  _handleGoogleLogin = async () => {
    try {
      const { type, user } = await Google.logInAsync({
        androidStandaloneAppClientId: '<ANDROID_CLIENT_ID>',
        iosStandaloneAppClientId: '<IOS_CLIENT_ID>',
        androidClientId: '603386649315-9rbv8vmv2vvftetfbvlrbufcps1fajqf.apps.googleusercontent.com',
        iosClientId: '603386649315-vp4revvrcgrcjme51ebuhbkbspl048l9.apps.googleusercontent.com',
        scopes: ['profile', 'email'],
      });

      <Text>
        Location: {this.state.locationResult}
      </Text>;

      switch (type) {
        case 'success': {
          Alert.alert('Logged in!', `Hi ${user.name}!`);
          break;
        }
        case 'cancel': {
          Alert.alert('Cancelled!', 'Login was cancelled!');
          break;
        }
        default: {
          Alert.alert('Oops!', 'Login failed!');
        }
      }
    } catch (e) {
      Alert.alert('Oops!', 'Login failed!');
    }

    <Text>
      Location: {this.state.locationResult}
    </Text>;
  };

  _getLocationAsync = async () => {
    let { status } = await Permissions.askAsync(Permissions.LOCATION);
    if (status !== 'granted') {
      this.setState({
        locationResult: 'Permission to access location was denied',
      });
    }

    let location = await Location.getCurrentPositionAsync({});
    this.setState({ locationResult: JSON.stringify(location) });
  };

  render() {
    return (
      <View style={styles.container}>
        // Logo
        <Image
          style={styles.logo}
          source={{
            uri: 'https://github.com/tussaneeashley/stay-woke/blob/master/stay-woke.jpg?raw=true',
          }}
          style={{ height: 350, width: 350 }}
        />
        <Text style={styles.paragraph}>
          Stay woke and stay safe while on the road!
        </Text>
        // Button

        <Button title="I'm sleepy!" onPress={this._handleButtonPress} />
        // Google
        <Button
          title="Login with Google to import emergency contacts"
          onPress={this._handleGoogleLogin}
        />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ff519d',
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#fffff',
  },
  button: {
    backgroundColor: '#566',
    color: '#85c68c',
    padding: 5,
    margin: 5,
  },
});
